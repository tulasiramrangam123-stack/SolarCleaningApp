SOLAR CLEANING REPORT - ANDROID APP SOURCE

This project is an offline-first Android WebView app for the supplied Solar Daily Cleaning Report workbook.
- Includes all 2,104 Grid Master records and inverter mapping.
- Enter From Grid and To Grid; grid/module/string counts are calculated from the workbook's Grid Master order.
- Supports Completed, Partial, Pending and Hold status.
- Saves entries locally on the phone (no account or internet required).
- Daily totals, inverter-wise totals, WhatsApp sharing, CSV export, JSON backup/restore.

To build the installable APK:
1. Open this folder in Android Studio (latest stable with Android SDK 35).
2. Allow Gradle sync/download when internet is available.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK is created under app/build/outputs/apk/debug/app-debug.apk.

No server or internet connection is needed when using the installed app. Internet is only needed once to download Android build dependencies if they are not already cached.
