# Solar Cleaning Report – Android APK build

This repository contains the Android Studio source project and a GitHub Actions workflow that builds a debug APK.

## Upload to GitHub

1. Create a GitHub repository named `SolarCleaningApp` (Public or Private is fine).
2. Extract this ZIP on your phone or computer.
3. Upload the **contents** of this folder to the repository root. The `.github` folder must also be uploaded.
4. Commit the files to the `main` branch.

## Build and download the APK

- Open the repository's **Actions** tab.
- Select **Build Android APK** and wait for the workflow to finish.
- Open the completed run.
- Under **Artifacts**, download `SolarCleaningReport-debug-apk`.
- Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone.

The workflow also runs automatically whenever you push a commit to `main`.

## Technical details

- Android Gradle Plugin: 8.7.3
- Gradle: 8.9
- Java: 17
- Android compile SDK: 35
- APK type: debug APK (suitable for testing and direct installation; not a Play Store release).

## Important data note

The included `grids.json` is the Grid Master data supplied with the project. Verify it against the latest approved workbook before using the app for official operational reporting.
