# Solar Cleaning Report – Offline Webpage

A mobile-friendly, single-file webpage for recording daily solar module cleaning and viewing grid-wise and inverter-wise reports.

## Features

- 2,104 Grid Master records embedded in `index.html`
- Grid-range daily entry
- Completed, Partial, Pending and Hold statuses
- Grid-wise, string-wise and module-wise calculations
- Inverter-wise report totals
- WhatsApp report sharing
- CSV export
- JSON backup and restore
- Local browser storage; no backend or login required

## Run locally

1. Download or extract this repository.
2. Open `index.html` in Chrome or another modern browser.
3. Use the page on the same device/browser where you entered the data.

The page itself has no external library or server dependency. For reliable offline use, keep a local copy of `index.html` on the device. Browser storage is device/browser-specific; export JSON backups regularly and do not clear browser data if you need to retain entries.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload **all files in this folder** to the repository root (especially `index.html`).
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then Save.
6. Wait for GitHub Pages to publish and open the URL shown on that page.

GitHub Pages hosting requires internet to open the hosted site. To use without internet, download `index.html` and open the local copy in your browser.

## Data and privacy

Entries are stored in the browser's local storage on the current device/browser. They are not automatically synced between phones or browsers. Use the built-in JSON backup/restore feature to move data between devices.

## Project structure

```text
SolarCleaningReport_GitHub_Repository/
├── index.html
├── README.md
└── .nojekyll
```

This is a static webpage project, not an Android APK.
