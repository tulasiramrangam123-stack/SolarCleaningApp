# MBNR-01 Solar Cleaning Android App

Fresh Android WebView project. It has no Kotlin plugin or Kotlin source, so the previous Java 8 / Kotlin 17 JVM target mismatch cannot occur. Java compile source and target are both 17.

## Features
- Offline parcel-wise grid search using the workbook's 2,699 unique Grid Master records and 9,680 original string records.
- Grid, modules, strings, inverter, SCB and IC details.
- Daily cleaning entries with Completed / Partial / Pending / Hold status.
- On-device history, WhatsApp-ready report text and CSV export.

## Build
GitHub Actions workflow: `.github/workflows/build-android.yml`. Run it manually from Actions or push to `main`. Download the `SolarCleaning-MBNR01-debug-apk` artifact.
