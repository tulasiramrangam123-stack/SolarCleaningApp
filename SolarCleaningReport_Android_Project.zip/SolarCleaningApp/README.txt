MBNR-01 Solar Cleaning Report Android Project

Parcels included:
- Rachala: INV 1 to INV 52
- Ponnakal: INV 53 to INV 96
- Gudibanda: INV 97 to INV 134

Features:
- Parcel selection in Daily Work Entry
- From Grid / To Grid range selection, scoped to selected parcel
- Automatic grid, inverter, string and module totals
- Daily cleaning status, labour/team and remarks
- Date-wise reports with parcel filter (All / individual parcel)
- WhatsApp share, CSV export, local history, JSON backup/restore
- Offline data stored in Android assets; daily entries stored locally on device

Build:
Open the SolarCleaningApp folder in Android Studio and build the app.
