# Solar Cleaning MBNR-01 - Green Updated v3

- Green-themed daily cleaning interface
- Multiple grid range selection
- Parcel-wise grid/module/string summary
- Inverter-wise module and string totals where source data supports exact allocation
- Generate Report (PDF): opens the Android/browser print dialog; choose Save as PDF
- English UI; offline grid master data embedded

Note: Inverter allocation is not guessed when the source master data does not identify an exact inverter allocation.
