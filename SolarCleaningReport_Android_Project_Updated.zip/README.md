# Solar Cleaning MBNR-01

Android WebView application for offline solar module cleaning records.

## Features
- Parcel-wise grid search for Rachala, Ponnakal, and Gudibanda
- Multiple grid-range selection with combined totals
- Grid-wise module, string, inverter, SCB, and IC details
- Daily cleaning entry, history, WhatsApp report, and CSV export
- Offline grid master embedded in the app
- English-only interface and custom Solar Cleaning launcher icon

## Grid range example
The search screen starts with three editable ranges:
- X1 to X5
- Y1 to Y5
- Z1 to Z5

Select a parcel and tap **View Grid Details** to calculate totals from the embedded grid master. Use **Add Another Range** to add more ranges.

## Build APK with GitHub Actions
1. Upload the contents of this ZIP to the root of your GitHub repository.
2. Open **Actions**.
3. Select **Build Solar Cleaning APK**.
4. Run the workflow or push a commit to `main`.
5. Open the successful run and download the `SolarCleaning-MBNR01-debug-apk` artifact.
6. Extract the artifact ZIP to get `app-debug.apk`.

The Android application ID is `com.solarcleaning.app`. If an older build with this same application ID is already installed, uninstall that older app before installing a newly signed debug APK if Android reports a package/signature conflict.
