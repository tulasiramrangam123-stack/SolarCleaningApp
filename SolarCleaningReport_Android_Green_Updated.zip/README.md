# Solar Cleaning MBNR-01

English-only offline Android app for MBNR-01 solar grid range summaries.

## Daily Cleaning screen
- Select cleaning date and parcel (Rachala, Ponnakal, Gudibanda).
- Add multiple From Grid / To Grid ranges.
- View combined unique grid, module, and string totals.
- View inverter-wise string totals when the source grid records contain an unambiguous single-inverter mapping.
- No cleaning-entry save, labour, supervisor, remarks, SCB/IC, or grid-wise detail table.

Grid master data is embedded in `SolarCleaningApp/app/src/main/assets/grid-data.js` and the app works offline.

## Build
Use JDK 17 and Gradle 8.9, then run `gradle assembleDebug` from `SolarCleaningApp`.
